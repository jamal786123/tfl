<?php
$file = file_get_contents("all-codes.txt");
$files = explode("\n", $file);
foreach($files as $file) {
    print("<option value=\"$file\">{$file}</option>\n");
}