<?php if(isset($_GET["v"])) { ?>
<!DOCTYPE html>
<body>
    <div class="center">
    <form method="GET" action="result.php">
        <div class="rendered-form">
            <div class="formbuilder-text form-group field-name">
                <label for="name" class="formbuilder-text-label">Name</label>
                <input type="text" class="form-control" name="name" access="false" id="name" />
            </div>
            <div class="formbuilder-text form-group field-cardNum">
                <label for="cardNum" class="formbuilder-text-label">Card Number</label>
                <input type="text" class="form-control" name="cardNum" access="false" maxlength="4" id="cardNum" />
            </div>
            <div class="formbuilder-text form-group field-cardType">
                <label for="cardType" class="formbuilder-text-label">Card Type</label>
                <select class="form-control" name="cardType" id="cardType">
                    <option value="amex">Amex</option>
                    <option value="visa">Visa</option>
                    <option value="maestro">Maestro</option>   
                    <option value="mastercard">Mastercard</option>
                    <option value=""></option>                
                </select>
            </div>
            <div class="formbuilder-date form-group field-date">
                <label for="date" class="formbuilder-date-label">Date</label>
                <input type="date" class="form-control" name="date" access="false" id="date" />
            </div>
            <div class="formbuilder-text form-group field-price">
                <label for="price" class="formbuilder-text-label">Price</label>
                <input type="text" class="form-control" name="price" access="false" id="price" />
            </div>
            <div class="formbuilder-select form-group field-start">
                <label for="start" class="formbuilder-select-label">Start</label>
                <select class="form-control" name="start" id="start">
                    <?php include("run.php"); ?>                    
                </select>
            </div>
            <div class="formbuilder-text form-group field-startTime">
                <label for="startTime" class="formbuilder-text-label">Start Time</label>
                <input type="text" class="form-control" name="startTime" access="false" maxlength="5" id="startTime" />
            </div>
            <div class="formbuilder-select form-group field-end">
                <label for="end" class="formbuilder-select-label">End</label>
                <select class="form-control" name="end" id="end">
                    <?php include("run.php"); ?>                    
                </select>
            </div>
            <div class="formbuilder-text form-group field-endTime">
                <label for="endTime" class="formbuilder-text-label">End Time</label>
                <input type="text" class="form-control" name="endTime" access="false" maxlength="5" id="endTime" />
            </div>
            <div class="formbuilder-text form-group field-submit">
                <input type="submit" class="form-control" name="submit"/>
            </div>
            <div 
        </div>
        </form>
    </div>

    <style>
        .center {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            padding: 10px;
        }
    </style>
</body>
<?php } else { ?>
    <h1>Welcome to auto-proxy</h1>
    <h2>Version = tfl.prod</h2>
<?php } ?>